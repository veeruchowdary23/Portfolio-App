package com.example.portfolioapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class WorkActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_work)
    }
}